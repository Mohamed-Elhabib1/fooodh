//كود تصميم مخصص لتحديد الحقول النصية داخل المنظومة
import 'package:flutter/material.dart';

class MyTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hintText;
  final bool obscureText;

  const MyTextField({
    super.key,
    required this.controller,
    required this.hintText,
    required this.obscureText,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      //تقوم بضبط مسافة اطار المدخلات  بحيث تعطي مساحة من اليمين الي اليسار 25
      padding: const EdgeInsets.symmetric(horizontal: 25.0),
      child: TextField(
        // التي تقوم بالقراء البيانات من حق النص
        controller: controller,
        //تقوم باخفاء البيانات المدخل من المستخدم في حالة true )(كمثال الباسورد)
        obscureText: obscureText,
        //المسؤول علي تصميم الحقل
        decoration: InputDecoration(
          enabledBorder: OutlineInputBorder(
              borderSide:
                  BorderSide(color: Theme.of(context).colorScheme.tertiary)),
          focusedBorder: OutlineInputBorder(
            borderSide:
                BorderSide(color: Theme.of(context).colorScheme.primary),
          ),
          // تقوم بتعبئة المربع الداخلي
          fillColor: Theme.of(context).colorScheme.tertiary,
          filled: true,
          hintText: hintText,
          hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary),
        ),
      ),
    );
  }
}
