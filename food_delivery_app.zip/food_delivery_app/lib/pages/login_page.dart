import 'package:flutter/material.dart';
import 'package:food_delivery_app/components/my_button.dart';
import 'package:food_delivery_app/components/my_textfield.dart';
import 'package:food_delivery_app/pages/forgotpassword.dart';
import 'package:food_delivery_app/pages/home_page.dart';

class Loginpage extends StatefulWidget {
  final void Function()? onTap;

  const Loginpage({super.key, required this.onTap});

  @override
  State<Loginpage> createState() => _LoginpageState();
}

class _LoginpageState extends State<Loginpage> {
  final TextEditingController username = TextEditingController();
  final TextEditingController password = TextEditingController();
  //final  prefixIcon: Icon(Icon) ;

  //login method
  void login() {
    /*
  fill out authentication here.....
  */
    //navigate To home page
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const HomePage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            //logo
            Icon(
              Icons.lock_open_rounded,
              size: 100,
              color: Theme.of(context).colorScheme.inversePrimary,
            ),
//مسافة /
            const SizedBox(height: 25),

            //message , app Slogan
            Text(
              "Food Delivery App",
              style: TextStyle(
                fontSize: 16,
                color: Theme.of(context).colorScheme.inversePrimary,
              ),
            ),

            const SizedBox(height: 25),

            //email textfiled
            MyTextField(
              controller: username,
              hintText: "Email",
              //Icon: Icons.email,

              obscureText: false,
            ),

            const SizedBox(height: 10),

            //email textfiled
            MyTextField(
              controller: password,
              // Icon: Icons.lock,
              hintText: "Password",
              obscureText: true,
            ),

            const SizedBox(height: 10),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const forgotpasswor(),
                      ),
                    );
                  },
                  child: Text(
                    "Forgot Password ? ",
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.inversePrimary,
                      //  fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                //
                //  onTap: forgotpasswor(),
              ]),
            ),
            const SizedBox(height: 10),

            //sign in Button

            MyButton(
              text: "Sign In",
              onTap: login,
            ),

            const SizedBox(height: 5),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                    child: Divider(
                  thickness: 0.5,
                  color: Theme.of(context).colorScheme.inversePrimary,
                )),
                Text(
                  "Not a member?  ",
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.inversePrimary),
                ),
                const SizedBox(height: 4),
                GestureDetector(
                  onTap: widget.onTap,
                  child: Text(
                    "Register Now? ",
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.inversePrimary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                    child: Divider(
                  thickness: 0.5,
                  color: Theme.of(context).colorScheme.inversePrimary,
                )),
              ],
            )
          ],
        ),
      ),
    );
  }
}
