import 'package:flutter/material.dart';

class forgotpasswor extends StatefulWidget {
  const forgotpasswor({super.key});

  @override
  State<forgotpasswor> createState() => _forgotpassworState();
}

class _forgotpassworState extends State<forgotpasswor> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("forgotpasswor"),
      ),
    );
  }
}
