import 'package:flutter/material.dart';
import 'package:food_delivery_app/models/users.dart';

import 'package:food_delivery_app/pages/home_page.dart';
import 'package:http/http.dart' as http;

class UsersOperation {
  Future<Users?> getUsers(TextEditingController username,
      TextEditingController password, BuildContext context) async {
    if (username.text.isEmpty || password.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('ارجو التاكد من ادخال اسم المستخدم وكلمة المرور'),
          duration: Duration(seconds: 6),
        ),
      );
      username.clear();
      password.clear();
      return null; // Return null if username or password is empty
    } else {
      final response = await http.get(Uri.parse(
          "https://nokbaapi.nokba.ly/api/GetUser/${username.text}/${password.text}"));

      if (response.statusCode == 200) {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => const HomePage()));

        Users us = Users();
        username.clear();
        password.clear();
        return us;
      } else {
        username.clear();
        password.clear();
        return null; // Return null if the response status code is not 200

        //create a user object and return it
      }
    }
  }

  Future<Users> Registeruser(
      TextEditingController username,
      TextEditingController password,
      TextEditingController phonenumber,
      BuildContext context) async {
    if (username.text.isEmpty ||
        password.text.isEmpty ||
        phonenumber.text.isEmpty) {
      var showSnackBar = ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              ' ارجو التاكد من ادخال اسم المستخدم وكلمة المرور ورقم الهاتف'),
          duration: Duration(seconds: 6),
        ),
      );
      username.clear();
      password.clear();
      phonenumber.clear();
      // Throw an exception when the fields are empty.
      throw Exception(
          'Username and password and phonenumber must not be empty.');
    } else {
      final response = await http
          .post(Uri.parse("https://nokbaapi.nokba.ly/api/userCreate"), body: {
        "user_name": username.text,
        "password": password.text,
        "phone_number": phonenumber.text
      });
      if (response.statusCode == 204) {
        //     DialogBox.showAlertDialog(context, "تم التسجيل بنجاح", "تاكيد الاتصال");
        Navigator.pop(context);

        Users us = Users(
            password: password.text,
            phonenumber: phonenumber.text,
            userName: username.text);
        // DialogBox.showAlertDialog(context, "تم الدخول بنجاح", "تاكيد الاتصال");
        username.clear();
        password.clear();
        phonenumber.clear();
        return us;
      } else {
        // It's better to throw an exception rather than just printing an error
        // so that the caller of this function can handle it appropriately.
        //      DialogBox.showAlertDialog(context, "Warning",
        //         "اسم المستخدم او كلمة المرور او رقم الهاتف خطأ");
        username.clear();
        password.clear();
        phonenumber.clear();
        throw Exception(
            "Failed to login: Username or password or phonenumber incorrect.");
      }
    }
  }
}
